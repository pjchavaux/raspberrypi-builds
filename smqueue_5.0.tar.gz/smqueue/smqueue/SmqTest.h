/*
* Copyright 2008 Free Software Foundation, Inc.
* Copyright 2011, 2013, 2014 Range Networks, Inc.
*
* This software is distributed under multiple licenses;
* see the COPYING file in the main directory for licensing
* information for this specific distribuion.
*
* This use of this software may be subject to additional restrictions.
* See the LEGAL file in the main directory for details.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/*
 * SmqTest.h
 *
 *  Created on: Dec 16, 2013
 *      Author: scott
 */

#ifndef SMQTEST_H_
#define SMQTEST_H_

void StartTestThreads();

#if 0
class SmqTest {
public:
	SmqTest();
	virtual ~SmqTest();
};
#endif


#endif /* SMQTEST_H_ */
