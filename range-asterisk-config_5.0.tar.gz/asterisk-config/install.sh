#!/bin/sh

# copy English error messages
cp en/*.gsm /var/lib/asterisk/sounds/en
