#ifndef _AST_FORMAT_ILBC_H_
#define _AST_FORMAT_ILBC_H_

struct ilbc_attr {
	unsigned int mode;
};

#endif /* _AST_FORMAT_ILBC_H */